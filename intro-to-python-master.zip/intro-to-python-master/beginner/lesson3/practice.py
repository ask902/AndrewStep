'''
Practice exercises for lesson 3 of beginner Python.
'''

# Level 1
# Ask the user if they are hungry
# If "yes": print "Let's get food!"
# If "no": print "Ok. Let's still get food!"

inp = input("Are you hungry? ")


# Level 2
# Ask the user if it is cold and if it is snowing
# If cold and snowing, print "Put on a hat and jacket"
# If only cold, print "Put on a jacket"
# If only snowing, print "Put on a hat"
# Otherwise, print "Have fun outside!"

is_cold = input("Is it cold outside? ")
is_snowy = input("Is it snowy outside? ")

# Level 3
# Ask the user for their first and last name
# If the user's first name comes before their last name
#   in the alphabet, print "first", otherwise "long"
# If the length of the first name is greater, print "long first",
#   if the last name is longer, print "long last", otherwise print "equal"

first = input("First name: ")
last = input("Last name: ")