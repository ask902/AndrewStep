print("Hello!")

answer = input("Do you want to go on an adventure (type yes or no)? ")
if answer == "yes":
  print("Once upon a time...")
  #continue your story here using print and input statements








else:
  print("Ok")
  
print("The end")