# 1. Write down what you think the output of these statements
#       will be BEFORE you run the code.

print("Hello world")
print("I am", 13)
print("I can co" + "de")
print("There are", 6, "apples " + "on the tree")

# 2. Modify the second print statement so you get the same output
#       without using commas.

cityName = input("Enter a city name: ")
print("It was a dark and stormy night in " +  cityName + ". [Rest of background here]")


