# intro-to-python
The exercises for our Introduction to Python curriculum
