# -- Part 1: What is the output? --

# 1.
foo = "bar"
print(foo)
print("foo")
 
 
 
#2.
a = True
b = False
c = False
 
if (a or b) and c: 
	print("coffee")
else: 
	print("tea") 


 
#3. 
def mul(a,b):
   return a * b
print(a*b == mul(a,b))

# -- Part 2: Loops --

# 1.
# Print each element of the list
lis = ["Interior", "Crocodile", "Alligator", "Chevrolet"]
for i in range(len(lis)):
   # Your code here:



# 2.
# End the loop using ‘break’ if the age is less than 18
age = 0
while age < 18:
   age = int(input("What is your age? "))
   # Your code here



# 3.
# Set x and y so that the loop prints the numbers
# 1, 2, 3, and 4 ONLY.
 
# Your code here
x =
y =
for i in range(x, y):
   print(i)

# -- Part 3: Getting Functional --
# Write a function (also called ‘method’) to perform the indicated operation.

# 1.
'''
Write a function that takes one number, n, as a
parameter and returns the sum of all numbers from 1
to n, inclusive.
 
e.g.
sum_to(1) -> 1
sum_to(3) -> 1 + 2 + 3 -> 6
sum_to(10) -> 55
'''
# Your code here





# 2.
'''
Write a function that counts the number
of vowels in a word.
 
Vowels are any of a, e, i, o, and u
 
e.g.
count_vowels("abc") -> 1
count_vowels("aeiou") -> 5
count_vowels("abracadabra") -> 5
'''
# Your code here

i = 0
while i < 5:
   print(i)
   i += 1